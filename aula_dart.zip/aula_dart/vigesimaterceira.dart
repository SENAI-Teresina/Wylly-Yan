void main() {
  double num1 = 4.5;
  double num2 = 2.2;
  double resultado = num1 * num2;
  print("O resultado da multiplicação de $num1 por $num2 é: $resultado");
}