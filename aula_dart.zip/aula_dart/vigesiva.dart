void main() {
  int dividendo = 10;
  int divisor = 3;

  int resto = dividendo % divisor;

  print('O resto da divisão de $dividendo por $divisor é: $resto');
}