void main() {
  double num1 = 5.8;
  double num2 = 3.2;
  double diferenca = num1 - num2;
  print("A diferença entre $num1 e $num2 é: $diferenca");
}