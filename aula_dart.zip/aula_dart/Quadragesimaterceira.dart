void main() {
  double largura = 8.0;
  double altura = 5.0;
  
  double perimetro = 2 * (largura + altura);

  print('O perímetro do retângulo com largura $largura e altura $altura é: $perimetro');
}