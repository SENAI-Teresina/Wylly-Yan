void main() {
  // Três números inteiros
  int numero1 = 10;
  int numero2 = 20;
  int numero3 = 30;

  // Calculando a soma dos três números
  int soma = numero1 + numero2 + numero3;

  // Exibindo a soma
  print('A soma dos três números é: $soma');
}