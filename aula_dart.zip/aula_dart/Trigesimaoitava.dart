mport 'dart:math';

void main() {
  double raio = 5.0;
  
  double volume = (4/3) * pi * pow(raio, 3);

  print('O volume da esfera com raio $raio é: $volume');
}