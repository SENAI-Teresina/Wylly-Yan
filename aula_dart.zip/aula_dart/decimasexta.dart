void main() {
  // Dois números inteiros
  int numero1 = 10;
  int numero2 = 20;

  // Calculando a soma dos dois números
  int soma = numero1 + numero2;

  // Exibindo a soma
  print('A soma dos dois números é: $soma');
}