void main() {
  // Dois números inteiros
  int numero1 = 5;
  int numero2 = 10;

  // Multiplicando os dois números e atribuindo o resultado a uma variável
  int resultado = numero1 * numero2;

  // Exibindo o resultado
  print('O resultado da multiplicação é: $resultado');
}