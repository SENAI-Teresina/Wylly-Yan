void main() {
  int numeroInteiro = 10;
  double numeroPontoFlutuante = 2.5;

  double resultado = numeroInteiro / numeroPontoFlutuante;

  print('O resultado da divisão é: $resultado');
}