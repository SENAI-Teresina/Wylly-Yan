void main() {
  double lado = 6.0;
  
  double perimetro = 3 * lado;

  print('O perímetro do triângulo equilátero com lado $lado é: $perimetro');
}