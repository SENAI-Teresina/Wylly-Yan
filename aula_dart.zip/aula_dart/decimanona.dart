void main() {
  // Dois números inteiros
  int dividendo = 10;
  int divisor = 3;

  // Calculando o resto da divisão
  int resto = dividendo % divisor;

  // Exibindo o resto da divisão
  print('O resto da divisão é: $resto');
}