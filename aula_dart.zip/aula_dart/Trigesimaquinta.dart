void main() {
  var numero1 = 10;
  var numero2 = 3;
  var numero3 = 5.5;
  
  var resultado = ((numero1 + numero2) * (numero3 - numero2)) / numero1 % numero2;

  print('O resultado da expressão é: $resultado');
}