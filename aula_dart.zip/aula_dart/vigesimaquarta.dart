void main() {
  double num1 = 10.0;
  double num2 = 2.5;
  double resultado = num1 / num2;
  print("O resultado da divisão de $num1 por $num2 é: $resultado");
}