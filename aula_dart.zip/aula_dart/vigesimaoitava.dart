void main() {
  int numeroInteiro = 5;
  double numeroPontoFlutuante = 3.7;

  double resultado = numeroInteiro * numeroPontoFlutuante;

  print('O resultado da multiplicação é: $resultado');
}