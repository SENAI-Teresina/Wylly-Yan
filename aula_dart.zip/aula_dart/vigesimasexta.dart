void main() {
  int numeroInteiro = 5;
  double numeroPontoFlutuante = 3.7;

  double soma = numeroInteiro + numeroPontoFlutuante;

  print('A soma é: $soma');
}