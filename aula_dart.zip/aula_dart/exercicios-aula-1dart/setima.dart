void main() {
  int numero = 5;
  int quadrado = numero * numero;
  print("O quadrado de $numero é: $quadrado");
}