void main() {
  int a = 15;
  int b = 4;
  int resultado = (a ~/ b) + (a % b);
  print("O resultado de a dividido por b mais o resto da divisão de a por b é: $resultado");
}