void main() {
  double fahrenheit = 68; // Exemplo: 68 graus Fahrenheit
  double celsius = (fahrenheit - 32) * 5 / 9;
  print("$fahrenheit graus Fahrenheit são $celsius graus Celsius.");
}