void main() {
  int r = 18;
  int s = 5;
  int resto = r % s;
  print("O resto da divisão de $r por $s é: $resto");
}
