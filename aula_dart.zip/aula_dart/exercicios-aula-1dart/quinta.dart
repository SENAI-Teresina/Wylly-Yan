void main() {
  int t = 12;
  int u = 3;
  int diferenca = t - (2 * u);
  print("A diferença entre $t e o dobro de $u é: $diferenca");
}