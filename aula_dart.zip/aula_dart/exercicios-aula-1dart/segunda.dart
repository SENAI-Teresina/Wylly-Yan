void main() {
  int m = 20;
  int n = 4;
  int produto = m * n;
  print("O produto de $m e $n é: $produto");
}