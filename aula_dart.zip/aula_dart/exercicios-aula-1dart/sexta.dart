void main() {
  int v = 27;
  int w = 4;
  int resultado = (v / w).round();
  print("O resultado da divisão de $v por $w, arredondado para o inteiro mais próximo, é: $resultado");
}