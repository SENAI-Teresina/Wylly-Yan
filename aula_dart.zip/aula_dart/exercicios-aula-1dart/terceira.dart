void main() {
  int p = 35;
  int q = 6;
  double resultado = p / q;
  print("O resultado da divisão de $p por $q é: $resultado");
}
