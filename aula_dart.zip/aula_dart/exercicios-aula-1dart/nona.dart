void main() {
  int c = 21;
  int d = 8;
  int diferenca = c - d;
  int quadradoDiferenca = diferenca * diferenca;
  print("O quadrado da diferença entre $c e $d é: $quadradoDiferenca");
}