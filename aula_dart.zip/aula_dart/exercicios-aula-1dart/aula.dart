void main() {
  int x = 15;
  int y = 7;
  int soma = x + y;
  print(soma);
  print("A soma de $x é $soma");
}
  