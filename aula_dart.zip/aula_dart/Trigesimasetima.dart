import 'dart:math';

void main() {
  double raio = 5.0;
  
  double circunferencia = 2 * pi * raio;

  print('A circunferência do círculo com raio $raio é: $circunferencia');
}