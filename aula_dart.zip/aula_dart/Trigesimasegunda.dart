void main() {
  var dividendo = 10;
  var divisor = 2;

  var resultado = dividendo / divisor;

  print('O resultado da divisão é: $resultado');
}