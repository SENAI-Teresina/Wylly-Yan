import 'dart:math';

void main() {
  double raio = 5.0;
  double altura = 12.0;
  
  double volume = pi * pow(raio, 2) * altura;

  print('O volume do cilindro com raio $raio e altura $altura é: $volume');
}