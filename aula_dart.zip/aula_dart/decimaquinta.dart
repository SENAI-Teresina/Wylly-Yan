void main() {
  // Comprimento e largura do retângulo
  double comprimento = 5.5;
  double largura = 3.0;

  // Calculando a área do retângulo
  double area = comprimento * largura;

  // Exibindo a área
  print('A área do retângulo é: $area');
}