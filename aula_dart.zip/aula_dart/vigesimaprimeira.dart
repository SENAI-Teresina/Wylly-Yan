void main() {
  double num1 = 3.5;
  double num2 = 2.7;
  double soma = num1 + num2;
  print("A soma de $num1 e $num2 é: $soma");
}