void main() {
  var dividendo = 10;
  var divisor = 3;

  var resultado = dividendo % divisor;

  print('O resto da divisão é: $resultado');
}