void main() {
  // Dois números inteiros
  int numero1 = 20;
  int numero2 = 10;

  // Calculando a diferença entre os dois números
  int diferenca = numero1 - numero2;

  // Exibindo a diferença
  print('A diferença entre os dois números é: $diferenca');
}