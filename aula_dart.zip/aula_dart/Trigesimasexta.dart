import 'dart:math';

void main() {
  double raio = 5.0;
  
  double area = pi * pow(raio, 2);

  print('A área do círculo com raio $raio é: $area');
}