void main() {
  // Número inteiro
  int inteiro = 10;

  // Número de ponto flutuante
  double flutuante = 5.5;

  // Convertendo o número inteiro em ponto flutuante
  double convertido = inteiro.toDouble();

  // Multiplicando o número convertido pelo número de ponto flutuante
  double resultado = convertido * flutuante;

  // Exibindo o resultado
  print('O resultado da multiplicação é: $resultado');
}