void main() {
  var numero1 = 5;
  var numero2 = 3.7;

  var resultado = numero1 + numero2;

  print('A soma é: $resultado');
}