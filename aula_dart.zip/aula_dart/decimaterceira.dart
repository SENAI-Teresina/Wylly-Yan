void main() {
  // Três números de ponto flutuante
  double numero1 = 10.5;
  double numero2 = 20.75;
  double numero3 = 15.0;

  // Calculando a média dos três números
  double media = (numero1 + numero2 + numero3) / 3;

  // Exibindo a média
  print('A média dos três números é: $media');
}