void main() {
  double base = 10.0;
  double altura = 8.0;
  
  double area = (base * altura) / 2;

  print('A área do triângulo com base $base e altura $altura é: $area');
}