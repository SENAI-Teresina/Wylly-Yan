class FiguraGeometrica {

  double area(double comp,double larg) {
    return comp*larg;
  }

  double perimetro(double comp, double larg) {
    return 2*(comp+larg);
  }
}