void main() {
  Aluno aluno = Aluno("João", 123456, "Engenharia");
  aluno.imprimirDetalhes();
}