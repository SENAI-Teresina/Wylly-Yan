class Triangulo {
  double lado1;
  double lado2;
  double lado3;
  
  Triangulo(this.lado1, this.lado2, this.lado3);
}