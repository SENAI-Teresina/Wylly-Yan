void main() {
  Circulo circulo = Circulo(5.0);
  double area = circulo.calcularArea();
  print("A área do círculo é: $area");
}