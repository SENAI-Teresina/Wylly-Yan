class Animal {
  void emitirSom() {
    print("O animal emite um som.");
  }
}