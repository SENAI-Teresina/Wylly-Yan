class Circulo {
  double raio;
  
  Circulo(this.raio);
  
  double calcularArea() {
    return 3.14159 * raio * raio;
  }
}