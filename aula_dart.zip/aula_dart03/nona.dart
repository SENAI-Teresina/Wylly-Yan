void main() {
  Retangulo retangulo = Retangulo(4.0, 6.0);
  double area = retangulo.calcularArea();
  print("A área do retângulo é: $area");
}