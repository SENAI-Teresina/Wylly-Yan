void main() {
  Pessoa pessoa1 = Pessoa("João", 30);
  Pessoa pessoa2 = Pessoa("Maria", 25);
  
  pessoa1.imprimirDetalhes();
  pessoa2.imprimirDetalhes();
}