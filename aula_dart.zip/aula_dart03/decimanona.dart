class Livro {
  String titulo;
  String autor;
  int anoPublicacao;
  
  Livro(this.titulo, this.autor, this.anoPublicacao);
}