class Circulo {
  double raio;
  
  Circulo(this.raio);
}