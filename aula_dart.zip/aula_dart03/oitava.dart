class Retangulo {
  double largura;
  double altura;
  
  Retangulo(this.largura, this.altura);
  
  double calcularArea() {
    return largura * altura;
  }
}