class Pessoa {
  String nome;
  int idade;
  
  Pessoa(this.nome, this.idade);
}