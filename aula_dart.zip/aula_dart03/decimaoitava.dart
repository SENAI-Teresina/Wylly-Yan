void main() {
  Cachorro cachorro = Cachorro();
  Gato gato = Gato();
  
  cachorro.emitirSom();
  gato.emitirSom();
}