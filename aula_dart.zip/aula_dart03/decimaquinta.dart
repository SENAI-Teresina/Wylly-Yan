void main() {
  Carro carro = Carro("Toyota", "Corolla", 2022);
  carro.imprimirDetalhes();
}