class Aluno {
  String nome;
  int matricula;
  String curso;
  
  Aluno(this.nome, this.matricula, this.curso);
}