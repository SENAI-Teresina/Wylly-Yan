class Retangulo {
  double largura;
  double altura;
  
  Retangulo(this.largura, this.altura);
}