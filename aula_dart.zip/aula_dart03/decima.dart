class ContaBancaria {
  double saldo;
  String titular;
  
  ContaBancaria(this.saldo, this.titular);
}