void main() {
  Livro livro = Livro("Dom Casmurro", "Machado de Assis", 1899);
  livro.imprimirDetalhes();
}